%% Helper Function to Convert Figure to Base64 (No File Save)
function base64str = figureToBase64(figure_handle)
    % Convert a figure image to Base64 string
    frame = getframe(figure_handle);
    image_data = frame.cdata;
    
    % Write image to temporary PNG file
    temp_filename = [tempname, '.png'];
    imwrite(image_data, temp_filename, 'png');
    
    % Read the image file and encode it in Base64
    fid = fopen(temp_filename, 'rb');
    img_bytes = fread(fid);
    fclose(fid);
    
    java_encoder = java.util.Base64.getEncoder();
    base64str = char(java_encoder.encode(img_bytes)'); % Convert to Base64
    delete(temp_filename); % Clean up temporary file
end